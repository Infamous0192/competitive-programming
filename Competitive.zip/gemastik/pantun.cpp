#include <iostream>
using namespace std;

int main() {
  int n, i, temp;
  scanf("%d", &n);
  int arr[n];
  for (i = 0; i < n; i++) {
    scanf("%d", &temp);
    arr[i] = temp;
  }
  long long int sum = 0, ans = 0;
  for (i = 0; i < n; i++) {
    scanf("%d", &temp);
    sum += temp;
  }
  for (i = 0; i < n; i++) {
    ans += (arr[i] * n) + sum;
  }
  printf("%lld\n", ans);
  return 0;
}