#include <iostream>
using namespace std;

int main() {
  int x[2];
  int y[2];
  scanf("%d%d", &x[0], &y[0]);
  scanf("%d%d", &x[1], &y[1]);
  int ans = abs(x[0] - x[1]) + abs(y[0] - y[1]);
  printf("%d\n", ans);
  return 0;
}