#include <iostream>
using namespace std;

int main() {
  int n, m, r, s, sum = 0, ans = 0;
  scanf("%d%d%d%d", &n, &m, &r, &s);
  int matriks[n][m];
  for (int i = 0; i < n; i++) {
    for (int j = 0; j < m; j++) {
      scanf("%d", &matriks[i][j]);
    }
  }

  s++;
  r++;

  for (int i = 0; i < r; i++) {
    for (int j = 0; j < s; j++) {
      sum = 0;
      for (int y = n * i / r; y < (n * (i + 1) / r); y++) {
        for (int x = m * j / s; x < (m * (j + 1) / s); x++) {
          sum += matriks[y][x];
        }
      }
      ans = max(ans, sum);
    }
  }
  printf("%d\n", ans);
  return 0;
}