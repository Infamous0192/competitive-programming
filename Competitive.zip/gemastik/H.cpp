#include <iostream>
#include <string.h>
using namespace std;

int main() {
	cout << 0 / 3;
}