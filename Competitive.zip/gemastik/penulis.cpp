#include <iostream>
using namespace std;

int main() {
  int t, n, i, j;
  while (t--) {
    scanf("%d", &n);
    int s[n], p[n], c[3];
    for (i = 0; i < n; i++) {
      scanf("%d", &s[i]);
    }
    for (i = 0; i < n; i++) {
      scanf("%d", &p[i]);
      for (j = 0; )
    }
  }
  return 0;
}