#include <stdio.h>

int main() {
  long long int a, b;
  scanf("%lld %lld", &a, &b);
  long long int sum = (b*(b+1) - (a-1)*a) / 2;
  long long int ans = sum % 1000000007;
  printf("%lld", ans);
  return 0;
}