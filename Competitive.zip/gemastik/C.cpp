#include <iostream>
using namespace std;

int main() {
  float x[4], y[4];
  for (int i = 0; i < 4; i++) {
    scanf("%f%f", &x[i], &y[i]);
  }
  float m[2], c[2];
  m[0] = (y[1] - y[0]) / (x[1] - x[0]);
  m[1] = (y[3] - y[2]) / (x[3] - x[2]);
  c[0] = (m[0] * x[0] * -1) + y[0];
  c[1] = (m[1] * x[3] * -1) + y[3];

  if (m[0] == m[1] && c[0] == c[1]) {
    printf("GARIS SAMA\n");
  } else if (m[0] == m[1]) {
    printf("SEJAJAR\n");
  } else {
    cout << (c[1] - c[0]) / (m[0] - m[1]) << " " << (m[0] * (c[1] - c[0]) / (m[0] - m[1])) + c[0];
  }
  return 0;
}