#include <iostream>
using namespace std;

int main() {
  int n, i = 1, j;
  int dp[10001][10001];
  while (n--) {
    int x1, y1, x2, y2;
    cin >> x1 >> y1 >> x2 >> y2;
    dp[0][i++] = (x2 - x1) * (y2 - y1);
    dp[i++][0] = (x2 - x1) * (y2 - y1);
  }
  for (i = 1; i < n; i++) {
    for (j = 1; j < n;j++) {
      
    }
  }
  return 0;
}