#include <stdio.h>

int main() {
  int n, max = -1, ans, i;
  int arr[] = {0, 0, 0, 0, 0};
  
  scanf("%d", &n);

  while (n--) {
    scanf("%d", &i);
    arr[i-1]++;
  }

  for (i = 0; i < 5; i++) {
    if (arr[i] > max) {
      max = arr[i];
      ans = i+1;
    }
  }

  printf("%d\n", ans);

  return 0;
}