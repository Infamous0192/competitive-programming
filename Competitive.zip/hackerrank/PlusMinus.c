#include <stdio.h>

int main() {
  int n, i;

  float p = 0, m = 0, z = 0, temp;

  scanf("%d", &n);

  for (i = 0; i < n; i++) {
    scanf("%d", &temp);

    if (temp > 0) p++;
    else if (temp == 0) z++;
    else m++;
  }

  printf("%f\n", p / n);
  printf("%f\n", m / n);
  printf("%f\n", z / n);

  return 0;
}