#include <stdio.h>

int main() {
  long temp, ans = 0, max = -1000000001, min = 1000000000;

  for (int i = 0; i < 5; i++) {
    scanf("%ld", &temp);

    if (temp > max) max = temp;
    if (temp < min) min = temp;

    ans += temp;
  }

  printf("%ld %ld\n", ans - max, ans - min);
  
  return 0;
}