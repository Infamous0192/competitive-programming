#include <stdio.h>

int main() {
  int t, n, ans;

  scanf("%d", &t);

  for (int i = 0; i < t; i++) {
    scanf("%d", &n);

    if (n + 5 - (n % 5) < 40 || n % 5 < 3 || n % 5 == 0) {
      ans = n;
    } else {
      ans = n + 5 - (n % 5);
    }
    printf("%d\n", ans);
  }

  return 0;
}