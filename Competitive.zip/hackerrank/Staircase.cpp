#include <iostream>
using namespace std;

int main() {
  int n;

  scanf("%d", &n);
  
  string ans = "";

  for (int i = 0; i < n; i++) {
    for (int j = n; j > 0; j--) {
      ans = (i >= j) ? " " + ans : "#" + ans;
    }
    if (i == n - 1) break;
    ans = "\n" + ans;
  }

  cout << ans << endl;
  

  return 0;
}