#include <stdio.h>

int main() {
  int n, min, max, minC = 0, maxC = 0, temp;

  scanf("%d", &n);

  scanf("%d", &temp);
  min = temp, max = temp, n--;

  while (n--) {
    scanf("%d", &temp);

    if (temp > max) {
      max = temp;
      maxC++;
    }
    if (temp < min) {
      min = temp;
      minC++;
    } 
  }

  printf("%d %d\n", maxC, minC);


  return 0;
}