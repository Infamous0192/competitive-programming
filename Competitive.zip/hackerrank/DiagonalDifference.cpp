#include <stdio.h>

int main() {
  int n, i, j, ans = 0;

  scanf("%d", &n);

  int arr[n][n];

  for (i = 0; i < n; i++) {
    for (j = 0; j < n; j++) {
      scanf("%d", &arr[i][j]);
    }
  }

  j = 0;
  for(i = 0; i < n; i++) {
    ans += (arr[j][i] - arr[j][n - j - 1]);
    j++;
  }

  printf("%d\n", (ans < 0) ? ans * -1 : ans);

  return 0;
}