#include <stdio.h>

int main() {
  int s, t, a, b, m, n, d, ans = 0;
  scanf("%d%d", &s, &t);
  scanf("%d%d", &a, &b);
  scanf("%d%d", &m, &n);

  while (m--) {
    scanf("%d", &d);
    if (a + d >= s && a + d <= t) ans++;
  }
  printf("%d\n", ans);

  ans = 0;
  while (n--) {
    scanf("%d", &d);
    if (b + d >= s && b + d <= t) ans++;
  }
  printf("%d\n", ans);

  return 0;
}