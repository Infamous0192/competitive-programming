#include <stdio.h>

int main() {
  int n, max = -1, ans = 0, num;

  scanf("%d", &n);
  
  for (int i = 0; i < n; i++) {
    scanf("%d", &num);
    if (num > max) {
      max = num;
      ans = 1;
    } else if (num == max) {
      ans++;
    }
  }

  printf("%d\n", ans);

  return 0;
}