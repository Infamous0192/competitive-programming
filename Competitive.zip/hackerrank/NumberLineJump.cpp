#include <stdio.h>

int main() {
  int x[2];
  int v[2];

  scanf("%d%d%d%d", &x[0], &v[0], &x[1], &v[1]);

  if (v[1] >= v[0]) printf("NO\n");
  else if ((x[1] - x[0])%(v[0] - v[1])  == 0) printf("YES\n");
  else printf("NO\n");
  

  return 0;
}